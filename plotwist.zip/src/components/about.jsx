import React from "react";

export const About = (props) => {
  return (
    <div id="comp">

   

    <div id="img-larga"></div>
    <div id="btn-princ"></div>


<div id="img-ancha"></div>
<div id="img-larga-text"></div>
<div id="btn-princ-2"></div>
<div id="img-cuadrada"></div>
    </div>
  );
};
